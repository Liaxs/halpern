<?php
//Menu
if (function_exists('register_nav_menus')) {
	register_nav_menus(array('headerNav' => 'Menu top'));
}
//Clase para <a>
	add_filter('nav_menu_link_attributes', 'class_nav_link', 10, 3);
	function class_nav_link($atts, $item, $args)
	{
		$class = 'nav-link menu-halpern js-scroll-trigger';
		$atts['class'] = $class;
		return $atts;
	}

if ( function_exists( 'add_theme_support' ) ) {
    add_theme_support( 'post-thumbnails' );
 }
?>