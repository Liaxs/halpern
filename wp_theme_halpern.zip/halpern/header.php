<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Halpern</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php bloginfo('template_url');?>/vendor/bootstrap/css/bootstrap.css" rel="stylesheet">


    <!-- Custom fonts for this template -->
    <link href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lato|Roboto" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->

    <link href="<?php bloginfo('template_url');?>/vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Custom styles for this template -->

    <link href="<?php bloginfo('template_url');?>/css/creative.css" rel="stylesheet">
    <link href="<?php bloginfo('template_url');?>/css/estilos.css" rel="stylesheet">

  </head>

  <body id="page-top">
<nav class="navbar navbar-inverse bg-inverse navbar-toggleable-sm fixed-top nav-halpern ">
                    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">
                        <img src="img/logo.png" width="120" height="30" class="d-inline-block align-top">
                    </a>
                    <!--
                    <div class="collapse navbar-collapse navBar-halper-collapse" id="navbarTogglerDemo01">
                    <div class="navbar-nav mr-auto ml-auto text-center ">
                      <a class="nav-item nav-link active menu-halpern js-scroll-trigger" href="#about">La empresa</a>
                      <a class="nav-item nav-link active menu-halpern js-scroll-trigger" href="#productos">Productos/Marcas</a>
                      <a class="nav-item nav-link active menu-halpern js-scroll-trigger" href="#servicios">Servicio</a>
                      <a class="nav-item nav-link active menu-halpern js-scroll-trigger" href="#novedades">Novedades</a>
                      <a class="nav-item nav-link active menu-halpern js-scroll-trigger" href="#contact">Contactos</a>
                    </div>
                  </div>
                   <div class="collapse navbar-collapse navBar-halper-collapse" id="navbarTogglerDemo01">
                        <ul class="navbar-nav mr-auto ml-auto text-center">
                          <li class="nav-item">
                            <a class=" nav-link active menu-halpern js-scroll-trigger" href="#about">La empresa</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link active menu-halpern js-scroll-trigger" href="#productos">Productos/Marcas</a>
                          </li>
                          <li class="nav-item">
                            <a class=" nav-link active menu-halpern js-scroll-trigger" href="#servicios">Servicio</a>
                          </li>
                          <li class="nav-item">
                            <a class=" nav-link active menu-halpern js-scroll-trigger" href="#novedades">Novedades</a>
                          </li>
                          <li class="nav-item">
                            <a class=" nav-link active menu-halpern js-scroll-trigger" href="#contact">Contactos</a>
                          </li>
                        </ul>
                      </div>-->
                      <?php wp_nav_menu(array(
                        'theme_location' => 'headerNav',
                        'container' => 'div',
                        'container_class' => 'collapse navbar-collapse navBar-halper-collapse',
                        'container_id' => 'navbarTogglerDemo01',
                        'items_wrap' => '<ul class="navbar-nav mr-auto ml-auto text-center ">%3$s</ul>',
                        'menu_class' => 'nav-item'

                        )); ?>
                  
            </nav>