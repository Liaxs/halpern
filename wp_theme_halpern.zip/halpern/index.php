<?php get_header();?>

    <header class="masthead text-center text-white d-flex pb-5">
            <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" style="position: absolute; z-index: -1 ">
      <div class="carousel-inner img-fluid">
            <div class="carousel-item active">
              <img class="d-block w-100 img-fluid" src="img/slider1.png" alt="First slide">
            </div>
            <div class="carousel-item">
              <img class="d-block w-100 img-fluid" src="img/slider2.png" alt="Second slide">
            </div>
          </div>
    </div>
      <div class="container my-auto">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h1 class="pt-4">
              Sistema de riego
            </h1>
          </div>
          <div class="col-lg-8 mx-auto">
            <p class=" mb-sm-5 mb-3 mt-sm-3">Lorem, ipsum dolor sit amet consectetur adipisicing elit</p>
            <a class="btn btn-success btn-xl js-scroll-trigger" href="#contact">Contactenos</a>
          </div>
        </div>
      </div>
    </header>
    <section class="bg-secondary pt-md-4 pt-0 pb-0 mb-0 pb-md-5 mb-md-5" id="about">
      <div class="container mb-md-5">
        <nav class="navbar text-center pt-4 pb-3 novedades-halpern contacto" style="color: #000000">
                    <h3>Quiénes Somos</h3>
            </nav>
        <!--<nav class="navbar navbar-light bg-light text-center d-block d-sm-none">
                    <h2 class="" style="margin-top: 20px; margin-bottom: 20px">La empresa</h2>
              </nav>-->
                  <div class="row">
                    <div class="col-md-5 col-sm">
                      <img src="img/laempresa.png" class="img-fluid">
                    </div>
                    <div class="col-md-6  col-sm" >
                      <h3 class="navbar-brand-halpern">La empresa</h3>
                      <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error nihil, neque laborum ducimus totam accusamus cumque vero nulla officia, libero repellat consectetur et facilis architecto voluptates! Tempore quas illum alias?</p>
                      <h3 class="navbar-brand-halpern">Misión</h3>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam veritatis dolor reprehenderit cumque fugit, voluptas in non esse deleniti dolore amet perspiciatis voluptatibus. Ratione aperiam, aliquam impedit veritatis deleniti cumque.</p>
                      <h3 class="navbar-brand-halpern">Visión</h3>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos architecto exercitationem itaque officiis debitis voluptatem, vitae placeat fuga ipsam. Iure iusto eveniet illum voluptatem rerum sapiente repellendus alias minima sunt!</p>
                    </div>
                  </div>
              </div>
    </section>
    <section id="productos" class="pt-0 pb-1">
              <nav class="navbar bg-dark text-center pt-4 pb-3 novedades-halpern contacto">
                    <h3>Productos</h3>
            </nav>  
            <div class="category_list bg-dark w-100 pb-0 mb-0">
              <a href="#productos2" class="category_item" category="filtros">Filtros</a>
              <a href="#productos2" class="category_item" category="conectores">Conectores</a>
              <a href="#productos2" class="category_item" category="tubos">Tubos</a>
              <a href="#productos2" class="category_item" category="valvulas">Válvulas</a>
            </div>
            <div class="container"> 
            <div class="row">
              <div class="col-md-4 col-12 push-md-4" id="productosTrash">
                <img src="img/productos.jpg" class="img-fluid">
              </div>
            </div>
            </div>
            
            <section class="products-list pb-0 pt-0 mx-auto">

              <div class="product-item" category="filtros" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/filtros/FILTROS-DE-MALLA-2.jpg" alt="" >
                <a href="#productos">Filtros de malla</a>
                </a>
              </div>
              <div class="product-item" category="filtros" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/filtros/FILTROS-DE-MALLA-3.jpg" alt="" >
                <a href="#productos">Filtros de malla</a>
              </a>
              </div>
              <div class="product-item" category="filtros" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/filtros/FILTROS-DE-MALLAder.jpg" alt="" >
                <a href="#productos">Filtros de malla</a>
              </a>
              </div>
              <div class="product-item" category="filtros" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/filtros/FILTROS-DE-MALLAizq.jpg" alt="" >
                <a href="#productos">Filtros de malla</a>
              </a>
              </div>

              <div class="product-item" category="conectores" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/conectores/CODO-ESPIGA.jpg" alt="" >
                <a href="#productos">Codo espiga</a>
              </a>
              </div>
              <div class="product-item" category="conectores" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/conectores/CODO-ESPIGA-16.jpg" alt="" >
                <a href="#productos">Codo espiga</a>
              </a>
              </div>
              <div class="product-item" category="conectores" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/conectores/CONECTOR-ESPIGA-RECTO.jpg" alt="" >
                <a href="#productos">Conector espiga recto</a>
              </a>
              </div>
              <div class="product-item" category="conectores" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/conectores/TE-ESPIGA.jpg" alt="" >
                <a href="#productos">Te espiga</a>
              </a>
              </div>

              <div class="product-item" category="tubos" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/tubos/tubos.jpg" alt="" class="img-fluid" >
                <a href="#productos">tubos</a>
              </a>
              </div>

              <div class="product-item" category="valvulas" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/valvulas/Valvula-automatica-simple-efecto.jpg" alt="" >
                <a href="#productos">Valvula automatica simple efecto</a>
              </a>
              </div>
              <div class="product-item" category="valvulas" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/valvulas/Valvula-combinada-triple-efecto.jpg" alt="" >
                <a href="#productos">Valvula combinada triple efecto</a>
              </a>
              </div>
              <div class="product-item" category="valvulas" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/valvulas/Valvula-kinetica-doble-efecto.jpg" alt="" >
                <a href="#productos">Valvula kinetica doble efecto</a>
              </a>
              </div>
              <div class="product-item" category="valvulas" data-toggle="modal" data-target="#exampleModal">
                <a href="#productos">
                <img src="img/productos/valvulas/Valvula-triple-efecto-ari.jpg" alt="" >
                <a href="#productos">Valvula triple efecto ari</a>
              </a>
              </div>
            </section>
       <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body mx-auto">
                 <ul>
                        <li>Listado 1</li>
                        <li>Listado 2</li>
                        <li>Listado 3</li>
                        <li>Listado 4</li>
                      </ul>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
              </div>
            </div>
          </div>
        </div>
        </section>
    <section class="p-0 pb-1 bg-dark" id="servicios">
              <nav class="navbar text-center pt-4 pb-3 novedades-halpern contacto">
                    <h3>Servicios</h3>
            </nav>          
      <div class="container-fluid p-0">
        <div class="row no-gutters popup-gallery">
          <div class=" col-sm-6 col-12">
            <a class="portfolio-box" href="img/slider1.png">
              <img class="img-fluid" src="img/slider1.png" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category ">
                    <h3 style="opacity: 1; color: #fff">Sistema de riego </h3>
                  </div>
                  <div class="project-name">
                    -Diseño
                    <br>
                    -Implementcion
                    <br>
                    -Reparación de equipos
                  </div>
                </div>
              </div>
            </a>
          </div>
          <div class=" col-sm-6 col-12">
            <a class="portfolio-box" href="img/slider2.png">
              <img class="img-fluid" src="img/slider2.png" alt="">
              <div class="portfolio-box-caption">
                <div class="portfolio-box-caption-content">
                  <div class="project-category ">
                    <h3 style="opacity: 1; color: #fff">Movimiento de suelo </h3>
                  </div>
                  <div class="project-name">
                    -Desmonte
                    <br>
                    -Nivelacion
                    <br>
                    -Zanjeos
                  </div>
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
    <section class="bg-light p-0 m-0" id="novedades">
              <nav class="navbar text-center pt-4 pb-3 novedades-halpern contacto" style="color: #000000">
                    <h3>Novedades</h3>
            </nav>
          <div class="container">
          <div class="card-group">
            <!--<div class="card mx-auto" style="max-width: 400px;">
              <img class="card-img-top img-fluid" src="img/Riego.jpg" alt="Card image cap" style="max-width: 400px;">
              <div class="card-body contacto-secondary mt-3">
                <h5 >Nuevo sistema de riego</h5>
                <p class="text-truncate">This is a wider card with supporting text</p>
                <a href="single.html" class="btn btn-success boton-novedades-halpern">Ver nota</a>
              </div>
            </div>-->
        <?php if ( have_posts() ) : ?>
        <?php while ( have_posts() ) : the_post(); ?>
        <div class="card mx-auto" style="max-width: 400px;">
          <?php if ( has_post_thumbnail() ) {
                      the_post_thumbnail('post-thumbnails', array('class' => 'card-img-top img-fluid'));
                  }
           ?>
              <div class="card-body contacto-secondary mt-3">
                <h5><?php the_title(); ?> </h5>
                <p class="text-truncate2"> <?php $text = get_the_excerpt(); echo wp_trim_words( $text, $num_words = 10, $more = '...' ); ?></p>
                <a href=" <?php the_permalink(); ?>" class="btn btn-success boton-novedades-halpern">Ver nota</a>
              </div>
            </div>
      <?php endwhile; ?>
      <?php endif; ?>
          </div>
        </div>

</section>

    <section class="bg-light pt-5" id="contact">
              <nav class="navbar  text-center contacto-secondary">
                    <h2  class="mb-4" >Contacto</h2>
                    <p>A continuación lo invitamos a enviarnos su consulta. La misma sera respondida en brevedad</p>
            </nav>
            <div class="container" >
            <div class="row">
              <div class="col-md-6 mx-auto justify-content-center">
              <form class=" form-inline2 justify-content-center">
                <div class="form-group">
                  <input type="email" class="form-control rounded" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nombre y apellido">
                </div>
                <div class="form-group">
                  <input type="email" class="form-control rounded " id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email">
                </div>
                <div class="form-group">
                  <textarea class="form-control rounded " id="exampleFormControlTextarea1" rows="3" placeholder="Escriba su consulta"></textarea>
                </div>
                
              </form>
              </div>
            </div>
              <div class="row">
              <div class="col-md-2 col-6 mx-auto ">
                <button type="submit" class="btn btn-success pr-5 pl-5 btn-halpern">Enviar</button>
              </div>
            </div>  
          </div>
        </div>

    </section>

<?php get_footer();?>