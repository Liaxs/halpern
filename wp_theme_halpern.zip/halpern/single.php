<?php get_header();?>
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-8">
				<div class="card mb-3">
					<h1 class="card-title">Nuevo sistema de riego</h1>
					<p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
				  <img class="card-img-top  img-fluid" src="img/Riego.jpg" alt="Card image cap">
				  <div class="card-body">
				    
				    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
				    
            <p class="card-text text-right text-muted  ">Compartir:
              <i class="icon ion-social-twitter social-blog  d-inline-flex"></i>
              <i class="icon ion-social-linkedin social-blog d-inline-flex"></i>
              <i class="icon ion-social-facebook social-blog d-inline-flex" ></i>

            </p>
				  </div>
				</div>
			</div>
			<div class="col-md-3  ml-md-5 mt-md-5 pt-5 mx-auto">
				<div class="card-deck">
					  <div class="card ">
					    <img class="card-img-top img-fluid" src="img/Riego.jpg" alt="Card image cap" >
					    <div class="card-body">
					      <h5 class="card-title">Card title</h5>
					      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
					    </div>
					    <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
              </div>
					  </div>
					  <div class="card-deck">
					  <div class="card">
					    <img class="card-img-top img-fluid" src="img/Riego.jpg" alt="Card image cap">
					    <div class="card-body">
					      <h5 class="card-title">Card title</h5>
					      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
					    </div>
					    <div class="card-footer">
					      <small class="text-muted">Last updated 3 mins ago</small>
					    </div>
					  </div>

					</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer();?>