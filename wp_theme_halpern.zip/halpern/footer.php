<footer class="footer-halpern pb-3">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-7 mx-auto">
            <img src="img/logo.png" class="img-fluid">
          </div>
          <div class="col-md-2 col-7 mx-auto mb-3">
            <ul class="nav flex-column ">
              <li class="nav-item">
                <a class="nav-link menu-halpern" href="#">La empresa</a>
              </li>
              <li class="nav-item">
                <a class="nav-link menu-halpern" href="#">Productos/Marcas </a>
              </li>
              <li class="nav-item">
                <a class="nav-link menu-halpern" href="#">Servicios</a>
              </li>
              <li class="nav-item">
                <a class="nav-link menu-halpern" href="#">Novedades</a>
              </li>
              <li class="nav-item">
                <a class="nav-link menu-halpern" href="#">Contacto</a>
              </li>
            </ul>
          </div>
          <div class="col-md-3 col-7 mx-auto ">  
                      <div class="row">
                            <div class="col-md-2 col-3">
                              <div class="redes rounded-circle text-center">
                                <i class="icon ion-social-facebook"></i>
                              </div>
                           </div>
                            <div class="col-md-2 col-3">
                            <div class="redes rounded-circle text-center">
                             <i class="icon ion-social-linkedin"></i>
                           </div>
                         </div>
                            <div class="col-md-2 col-3 ">
                             <div class="redes rounded-circle text-center">
                             <i class="icon ion-social-twitter"></i>
                           </div>
                         </div>
                        </div>
          </div>
          </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="<?php bloginfo('template_url');?>/vendor/jquery/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="<?php bloginfo('template_url');?>/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="<?php bloginfo('template_url');?>/js/creative.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/js/script.js"></script>

  </body>

</html>